# JavaScript Masterclass

Chapter-wise JavaScript examples for beginners.

## Chapters
1. Variables
2. Data Types
3. Operators
4. Conditions
5. Loops
6. Functions
7. Arrays
8. Objects
9. Async JavaScript
10. DOM Basics
