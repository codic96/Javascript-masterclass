// Chapter 3: Operators
let a=10,b=5;
console.log(a+b,a-b,a*b,a/b);