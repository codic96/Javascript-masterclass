// Chapter 6: Functions
function add(a,b){return a+b;}
console.log(add(2,3));