// Chapter 1: Variables
let name='Vipin';
const pi=3.14159;
console.log(name, pi);