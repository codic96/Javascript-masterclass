// Chapter 2: Data Types
let age=25;
let isActive=true;
console.log(typeof age, typeof isActive);