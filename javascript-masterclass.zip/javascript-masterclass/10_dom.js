// Chapter 10: DOM
// document.getElementById('demo').innerText='Hello';