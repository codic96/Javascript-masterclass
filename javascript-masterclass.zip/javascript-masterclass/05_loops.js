// Chapter 5: Loops
for(let i=1;i<=5;i++) console.log(i);