// Chapter 8: Objects
const user={name:'Vipin',age:30};
console.log(user.name);