// Chapter 7: Arrays
const nums=[1,2,3];
console.log(nums.map(x=>x*2));