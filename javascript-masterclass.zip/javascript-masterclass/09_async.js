// Chapter 9: Async JavaScript
setTimeout(()=>console.log('Done'),1000);