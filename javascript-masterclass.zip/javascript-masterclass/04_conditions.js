// Chapter 4: Conditions
let marks=85;
if(marks>=50){console.log('Pass');}